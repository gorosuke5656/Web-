<?php
  session_start();
  //登録処理 ?> <html> <body>
  <h1>登録しました</h1> </body> </html>

