<?php
   require_once("function.php");
   session_start();
   header("Content-type: text/html; charset=utf-8");

   //パラメーター取得
   $id = $_POST['id'];
   $password = $_POST['password'];

   //簡易ログイン判定
   if ($id != "yamada" && $password != "pass") {
    $_SESSION["error_status"] = 1;
    header("HTTP/1.1 301 Moved Permanently");
    header("Location: login.php");
    exit();
   }

    //セッション ID の振り直し
    session_regenerate_id(true);

    //セッションに ID を格納
    $_SESSION['id'] = $id;

    //リダイレクト
    header("HTTP/1.1 301 Moved Permanently");
    header("Location: welcome.php");

