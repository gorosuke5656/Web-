<?php
  session_start();
  header("Content-type: text/html; charset=utf-8");
  //セッション破棄
  $_SESSION = array();
  session_destroy();
  //ログアウト情報更新
  session_start();
  $_SESSION["logout_status"] = 1;
   //リダイレクト
  header("HTTP/1.1 301 Moved Permanently");
  header("Location: login.php");

