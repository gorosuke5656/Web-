<html>
<meta charset="UTF-8">
<head>
<title>ログイン処理</title>
</head>
<body>
<?php
$mysqli = new mysqli('localhost', 'tokoroten', '1qaz2wsx3edc$', 'testuser');
$uid = $_POST['uid'];
$pass = $_POST['password'];
$sql= "SELECT * FROM users where uid = '$uid' AND passwd = '$pass'";
$result = $mysqli->query($sql);
if ($result->num_rows == 0) {
echo "ユーザ名または、パスワードに誤りがあります。";
exit;
}
while ($row = mysqli_fetch_assoc($result)) {
print('mail addressはこちらです '.$row['mail']);
print('<br>');
}
$mysqli->close();
?>
<a href="top.html">ログイン画面に戻る</a>
</body>
</html>