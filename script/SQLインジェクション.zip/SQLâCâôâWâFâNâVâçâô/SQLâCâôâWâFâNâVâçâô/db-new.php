<html>
<meta charset="UTF-8">
<head>
<title>ログイン処理</title>
</head>
<body>
<?php
$mysqli = new mysqli('localhost', 'gorosuke5656', '1qaz2wsx3edc$', 'testuser');
$uid = $_POST['uid'];
$pass = $_POST['password'];
$sql =  $mysqli ->prepare("SELECT * FROM users where uid = ? AND passwd = ?");
$sql ->bind_param("ss",$uid,$pass);
$sql ->execute();
$sql ->bind_result($uid,$passwd,$mail);
$sql ->store_result();

if ($result->num_rows == 0) {
echo "ユーザ名または、パスワードに誤りがあります。";
exit;
}
while ($sql->fetch()){) {
print('mail addressはこちらです '.$row['mail']);
print('<br>');
}
$mysqli->close();
?>
<a href="top.html">ログイン画面に戻る</a>
</body>
</html>